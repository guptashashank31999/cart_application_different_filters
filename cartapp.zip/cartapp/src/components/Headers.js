import React from 'react'
import Container from 'react-bootstrap/Container';
import Navbar from 'react-bootstrap/Navbar';

const Headers = () => {
  return (
    <div>
     
    </div>
  )
}

export default Headers
