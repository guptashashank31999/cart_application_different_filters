import './App.css';
import Headers from './components/Headers';


function App() {
  return (
    <div>
    <Headers/>
 <h2>h2</h2>
    </div>
  );
}

export default App;
